<?php

	 class PublicacionConsultaResultado{

		public $cantTotal=0;
		public $publicaciones=[];

    }