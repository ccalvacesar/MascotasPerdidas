<?php
/* Smarty version 3.1.30, created on 2022-07-31 21:03:48
  from "C:\xampp\htdocs\Phperros\views\registro\index.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_62e6d214e7f768_85269336',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2f34380c8e4565696955ce9cd0de2bd5187fdf99' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Phperros\\views\\registro\\index.tpl',
      1 => 1573670791,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navBar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_62e6d214e7f768_85269336 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<link rel="stylesheet" type="text/css" href="css/login-registro.css">
<?php echo '<script'; ?>
 type="text/javascript" src="js/registro.js"><?php echo '</script'; ?>
>
<body>
<?php $_smarty_tpl->_subTemplateRender("file:navBar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="container">
	<div class="login">
		<h4>Registrarse en <?php echo $_smarty_tpl->tpl_vars['nombreSitio']->value;?>
</h4>
			<hr>
        		<form id="formRegistro" method="POST" action="Registro/registro" class="login-inner">
    				<input type="text" required class="form-control" id="nombre-completo" name="nombre-completo" placeholder="Nombre Completo">
    				<input type="email" required class="form-control email" id="email" name="email" placeholder="Email">
    				<input type="password" required class="form-control password" id="password" name="password" placeholder="Contraseña">
    				<div id="error-password" class="alert alert-danger"><i class='fa fa-exclamation-triangle'></i> <strong>Error!</strong> La contraseña debe contener al menos 8 caracteres, una letra y un número</div>
					<label class="checkbox-inline">
						<!--<input type="checkbox" id="remember" value="Remember me"> Remember me-->
					</label>
					<button class="btn btn-block btn-lg btn-success submit" type="submit"> <i class="fa fa-pencil"></i> Registrarme!</button>
				</form>
				<?php if (isset($_smarty_tpl->tpl_vars['mensaje']->value)) {?>
				<hr>
					<?php if ($_smarty_tpl->tpl_vars['mensaje']->value['es_error']) {?>
						<div class="alert alert-danger">
						  <i class='fa fa-exclamation-triangle'></i>
						  <strong>Error!</strong> 
					<?php } else { ?>
						<div class="alert alert-success">
						<i class='fa fa-check-circle'></i>
						<strong> Felicitaciones!</strong> 		
					<?php }?>
					<?php echo $_smarty_tpl->tpl_vars['mensaje']->value['feedback'];?>

					</div>
				<?php }?>

			<!--<a href="#" class="btn btn-sm btn-default forgot">Forgot your password?</a>-->
	</div>
</div>
	<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

</body>
<?php }
}
