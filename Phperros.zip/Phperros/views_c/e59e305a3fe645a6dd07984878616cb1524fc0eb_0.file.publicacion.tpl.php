<?php
/* Smarty version 3.1.30, created on 2022-08-01 02:56:23
  from "C:\xampp\htdocs\Phperros\views\publicacion\publicacion.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_62e724b7bc8968_28410364',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e59e305a3fe645a6dd07984878616cb1524fc0eb' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Phperros\\views\\publicacion\\publicacion.tpl',
      1 => 1573670791,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62e724b7bc8968_28410364 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="publicacion-item col-md-4 col-sm-6 col-xs-12">
  <h5 class="card-title">
  </h5>
  <div >
    <a target="_blank" href="Publicacion/verDetalle/<?php echo $_smarty_tpl->tpl_vars['pub']->value['id'];?>
"><img class="pubimage card-img-top" src="<?php echo $_smarty_tpl->tpl_vars['pub']->value['img'];?>
" alt=""></a>
    <?php if ($_smarty_tpl->tpl_vars['pub']->value['tipo'] == 'E') {?>
      <div class="publicacion-tipo-alert alert alert-success" role="alert" style="text-align: center;padding: 0;" ><i class='fa fa-check-circle'></i> Encontrado</div>
    <?php } else { ?>
      <div class="publicacion-tipo-alert alert alert-danger" role="alert"  style="text-align: center;padding: 0;"><i class='fa fa-search'></i> Perdido</div>
    <?php }?>
    <div class="publicacion-descripcion">
      <h4 class="card-title">
        <a target="_blank" href="Publicacion/verDetalle/<?php echo $_smarty_tpl->tpl_vars['pub']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['pub']->value['titulo'];?>
</a>
      </h4>
      <p class="card-text"><?php echo $_smarty_tpl->tpl_vars['pub']->value['descripcion'];?>
</p>
    </div>
  </div>
</div>


<?php }
}
