<?php
/* Smarty version 3.1.30, created on 2022-07-31 20:52:32
  from "C:\xampp\htdocs\Phperros\views\masterPage.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_62e6cf70b12366_97095332',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2f358d79368e4f7d52c7a5b6633755493d51e4f9' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Phperros\\views\\masterPage.tpl',
      1 => 1573670791,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navBar.tpl' => 1,
    'file:publicacion/publicacion.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_62e6cf70b12366_97095332 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="en">
  
  <?php $_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


  <body>

    <?php $_smarty_tpl->_subTemplateRender("file:navBar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>



    <!-- Page Content -->
    <div class="container" style="padding-bottom: 50px;">

      <!-- Page Heading -->
      <div class="row">
        <div class="col-md-10 col-sm-10 col-xs-12">
          <h1 class="my-4">Ahora!
            <small>Últimos <?php echo $_smarty_tpl->tpl_vars['cantidadAnunciosHome']->value;?>
 anuncios en <?php echo $_smarty_tpl->tpl_vars['nombreSitio']->value;?>
</small>
          </h1>
        </div>
        <div>
           <a href="Publicacion/vertodas" class="fa fa-search" style="position:relative;top:45%; font-size:23px">Ver todas</a>
        </div>
      </div>
      <div class="row my-4">

          <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['publicaciones']->value, 'pub');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['pub']->value) {
?>

              <?php $_smarty_tpl->_subTemplateRender("file:publicacion/publicacion.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>

             
          <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>


      </div>
      <!-- /.row -->
    </div>
    <!-- /.container -->
    <?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>



    <!-- Bootstrap core JavaScript -->
    <?php echo '<script'; ?>
 src="vendor/jquery/jquery.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="vendor/bootstrap/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>

  </body>

</html>
<?php }
}
