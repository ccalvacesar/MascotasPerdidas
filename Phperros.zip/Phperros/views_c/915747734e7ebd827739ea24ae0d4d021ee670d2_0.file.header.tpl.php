<?php
/* Smarty version 3.1.30, created on 2022-07-31 20:52:32
  from "C:\xampp\htdocs\Phperros\views\header.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_62e6cf70b6d657_13902758',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '915747734e7ebd827739ea24ae0d4d021ee670d2' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Phperros\\views\\header.tpl',
      1 => 1573670791,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62e6cf70b6d657_13902758 (Smarty_Internal_Template $_smarty_tpl) {
?>
  <head>
    <base href="<?php echo $_smarty_tpl->tpl_vars['baseUrl']->value;?>
">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['descripcionSitio']->value;?>
">
    <meta name="author" content="<?php echo $_smarty_tpl->tpl_vars['autorSitio']->value;?>
">

    <title><?php echo $_smarty_tpl->tpl_vars['nombreSitio']->value;?>
</title>
    <?php echo '<script'; ?>
 type="text/javascript" src="vendor/jquery/jquery.min.js"><?php echo '</script'; ?>
>
    
    <?php echo '<script'; ?>
 type="text/javascript" src="vendor/bootstrap/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/3-col-portfolio.css" rel="stylesheet">
    
    <link rel="stylesheet" type="text/css" href="css/owlcarousel/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="css/owlcarousel/owl.theme.default.min.css">

    <link href="fonts/fonts-awesome/css/font-awesome.min.css" rel="stylesheet">

    <link href="css/main.css" rel="stylesheet">

    <link href="fonts/fonts-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link rel="shortcut icon" type="image/png" href="favicon.png"/>

  </head><?php }
}
