<?php
/* Smarty version 3.1.30, created on 2022-07-31 21:24:54
  from "C:\xampp\htdocs\Phperros\views\navBar.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_62e6d706a98a87_51749698',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '300334d43d751d32a3d62fb220d4f2630f2b5ae1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Phperros\\views\\navBar.tpl',
      1 => 1659295490,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62e6d706a98a87_51749698 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
  <div class="container">
    <a class="navbar-brand" href="Index"><?php echo $_smarty_tpl->tpl_vars['nombreSitio']->value;?>
</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <?php if (!isset($_smarty_tpl->tpl_vars['buscadorsinform']->value)) {?>
            <form id="form_busqueda" method="GET" action="Publicacion/vertodas">
                <div class="input-group mb-3">
                  <div class="input-group-prepend" 
                      onclick="document.getElementById('form_busqueda').submit();return false;">
                        <a class="fa fa-search input-group-text" style="color:gray"></a>
                  </div>
                   <input id="search-input" class="form-control input-md" placeholder="Buscar..." autocomplete="off" spellcheck="false" autocorrect="off" tabindex="1" name="busqueda"
                   value="<?php if (isset($_smarty_tpl->tpl_vars['busqueda']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['busqueda']->value;?>
 <?php }?>">
                </div>
            </form>
          <?php } else { ?>
              <div class="input-group mb-3">
                  <div class="input-group-prepend">
                        <a class="fa fa-search input-group-text" style="color:gray"></a>
                  </div>
                  <?php if (isset($_smarty_tpl->tpl_vars['busqueda']->value)) {?> 
                    <input id="search-input" class="form-control input-md" placeholder="Buscar..." autocomplete= "off" spellcheck="false" autocorrect="off" tabindex="1" name="busqueda"
                       value="">
                  <?php } else { ?>  
                    <input id="search-input" class="form-control input-md" placeholder="Buscar..." autocomplete=   "off" spellcheck="false" autocorrect="off" tabindex="1" name="busqueda"
                       value="<?php echo $_smarty_tpl->tpl_vars['busqueda']->value;?>
 ">
                  <?php }?>
                  
                </div>
          <?php }?>
        </li>
         <?php if (($_smarty_tpl->tpl_vars['hayUsuarioLogueado']->value)) {?>
          <li class="nav-item active">
              <a class="nav-link" href="">Hola, <?php echo $_smarty_tpl->tpl_vars['usuarioLogueado']->value['nombre'];?>
!</a>
              <span class="sr-only">(current)</span>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="PanelUsuario"><i class='fa fa-user'></i> Panel de usuario</a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="Login/logout"><i class='fa fa-sign-out'></i> Cerrar sesión</a>
          </li>
          <?php } else { ?>
              <a class="nav-link" href="Login"><i class='fa fa-sign-in'></i> Iniciar sesión</a>
              <span class="sr-only">(current)</span>
          <?php }?>
      </ul>
    </div>
  </div>
</nav><?php }
}
