<?php
/* Smarty version 3.1.30, created on 2022-08-01 03:17:29
  from "C:\xampp\htdocs\Phperros\views\paginacion.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_62e729a91df0e0_94718949',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '857ee91a5dd830c92640aed72dec0fb081d72651' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Phperros\\views\\paginacion.tpl',
      1 => 1573670791,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62e729a91df0e0_94718949 (Smarty_Internal_Template $_smarty_tpl) {
?>
<ul class="pagination justify-content-center">
        
     <?php if ($_smarty_tpl->tpl_vars['cantpages']->value > 1) {?> 
        <?php if ($_smarty_tpl->tpl_vars['paginaseleccionada']->value != 1) {?>
        <li class="page-item">
          <p class="page-back page-link" aria-label="Previous">
            <span aria-hidden="true">&laquo;</span>
            <span class="sr-only">Previous</span>
          </p>
        </li>
        <?php }?>
        <?php
$_smarty_tpl->tpl_vars['current'] = new Smarty_Variable(null, $_smarty_tpl->isRenderingCache);$_smarty_tpl->tpl_vars['current']->step = 1;$_smarty_tpl->tpl_vars['current']->total = (int) ceil(($_smarty_tpl->tpl_vars['current']->step > 0 ? $_smarty_tpl->tpl_vars['cantpages']->value+1 - (1) : 1-($_smarty_tpl->tpl_vars['cantpages']->value)+1)/abs($_smarty_tpl->tpl_vars['current']->step));
if ($_smarty_tpl->tpl_vars['current']->total > 0) {
for ($_smarty_tpl->tpl_vars['current']->value = 1, $_smarty_tpl->tpl_vars['current']->iteration = 1;$_smarty_tpl->tpl_vars['current']->iteration <= $_smarty_tpl->tpl_vars['current']->total;$_smarty_tpl->tpl_vars['current']->value += $_smarty_tpl->tpl_vars['current']->step, $_smarty_tpl->tpl_vars['current']->iteration++) {
$_smarty_tpl->tpl_vars['current']->first = $_smarty_tpl->tpl_vars['current']->iteration == 1;$_smarty_tpl->tpl_vars['current']->last = $_smarty_tpl->tpl_vars['current']->iteration == $_smarty_tpl->tpl_vars['current']->total;?>  
          <?php if ($_smarty_tpl->tpl_vars['paginaseleccionada']->value == $_smarty_tpl->tpl_vars['current']->value) {?> 
            <li class="page-number page-item active">
                
          <?php } else { ?>
            <li class="page-number page-item">
          <?php }?>
              <span class="page-link"><?php echo $_smarty_tpl->tpl_vars['current']->value;?>
</span>
            </li>
        <?php }
}
?>

        <?php if ($_smarty_tpl->tpl_vars['paginaseleccionada']->value < $_smarty_tpl->tpl_vars['cantpages']->value) {?>
          <li class="page-item">
            <p class="page-forward page-link"  aria-label="Next">
              <span aria-hidden="true">&raquo;</span>
              <span class="sr-only">Next</span>
            </p>
          </li>
        <?php }?>
      <?php }?>
</ul><?php }
}
