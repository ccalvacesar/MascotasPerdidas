<?php
/* Smarty version 3.1.30, created on 2022-08-01 02:40:45
  from "C:\xampp\htdocs\Phperros\views\publicacion\cerrar-publicacion.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_62e7210d2b8220_69604871',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '10e3c05ebbc4f4273ef25c61f385f3537443cd06' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Phperros\\views\\publicacion\\cerrar-publicacion.tpl',
      1 => 1573670791,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62e7210d2b8220_69604871 (Smarty_Internal_Template $_smarty_tpl) {
if ($_smarty_tpl->tpl_vars['hayUsuarioLogueado']->value) {?>
	<?php if ($_smarty_tpl->tpl_vars['usuarioLogueado']->value['id'] == $_smarty_tpl->tpl_vars['publicacion']->value['usuario_id'] && $_smarty_tpl->tpl_vars['publicacion']->value['abierta'] == 1) {?>
	<hr>
	<h4>Cerrar publicación</h4>
		<div class="input-group cerrar-publicacion">
		  <select class="custom-select" id="select-publicacion-exito">
		    <option selected>¿Con éxito?</option>
		    <option value="1">Sí</option>
		    <option value="0">No</option>
		  </select>
		  <div class="input-group-append">
		    <button class="btn btn-danger" id='btn-cerrar-publicacion' type="button" data-id-publicacion="<?php echo $_smarty_tpl->tpl_vars['publicacion']->value['id'];?>
"><i class="fa fa-key"></i> Cerrar publicación</button>
		  </div>
		</div>
		<div id='cerrar-publicacion-respuesta'></div>
	<?php }
}
}
}
