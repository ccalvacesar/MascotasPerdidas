<?php
/* Smarty version 3.1.30, created on 2022-08-01 02:40:42
  from "C:\xampp\htdocs\Phperros\views\panelUsuario\publicaciones-usuario.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_62e7210a71ad80_73331112',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f4b08c365c95d565aff46ab754a36c87523a56d1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Phperros\\views\\panelUsuario\\publicaciones-usuario.tpl',
      1 => 1573670791,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62e7210a71ad80_73331112 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div>Estas son tus publicaciones en <?php echo $_smarty_tpl->tpl_vars['nombreSitio']->value;?>
:</div>
<div class="table-responsive">
	<table class="table">
	  <thead>
	    <tr>
	      <th scope="col">Titulo</th>
	      <th scope="col">Tipo</th>
	      <th scope="col">Estado</th>
	      <th scope="col">Acciones</th>
	    </tr>
	  </thead>
	  <tbody>
	  	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['publicaciones']->value, 'pub');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['pub']->value) {
?>
	    <tr>
	      <td scope="row"><?php echo $_smarty_tpl->tpl_vars['pub']->value['titulo'];?>
</td>
	      <td><?php echo $_smarty_tpl->tpl_vars['pub']->value['tipo'];?>
</td>
	      <td><?php echo $_smarty_tpl->tpl_vars['pub']->value['estado'];?>
</td>
	      <td>
	      	<a href="Publicacion/verDetalle/<?php echo $_smarty_tpl->tpl_vars['pub']->value['id'];?>
" target="_blank" class="btn btn-sm btn-primary"><i class="fa fa-external-link"></i> Ver </a>
	      	<a href="Publicacion/generarPublicacionPDF/<?php echo $_smarty_tpl->tpl_vars['pub']->value['id'];?>
" target="_blank" class="btn btn-sm btn-primary"><i class="fa fa-file-pdf-o"></i> Generar PDF</a>
	      </td>
	    </tr>
	   <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

	  </tbody>
	</table>
</div><?php }
}
