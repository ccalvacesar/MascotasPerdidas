<?php
/* Smarty version 3.1.30, created on 2022-07-31 20:52:39
  from "C:\xampp\htdocs\Phperros\views\login\index.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_62e6cf77013546_92368377',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a9403217e1b15fffc621b6e0fad719372369141a' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Phperros\\views\\login\\index.tpl',
      1 => 1573670791,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navBar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_62e6cf77013546_92368377 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<link rel="stylesheet" type="text/css" href="css/login-registro.css">
<body>
<?php $_smarty_tpl->_subTemplateRender("file:navBar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="container">
	<div class="login">
		<h4>Ingresar a <?php echo $_smarty_tpl->tpl_vars['nombreSitio']->value;?>
.</h4>
			<hr>
        		<form method="POST" action="Login/login" class="login-inner">
    				<input type="email" required class="form-control email" name="email" id="email-input" placeholder="Email">
    				<input type="password" required class="form-control password" name="password" id="password-input" placeholder="Contraseña">
					<label class="checkbox-inline">
						<!--<input type="checkbox" id="remember" value="Remember me"> Remember me-->
					</label>
					<button class="btn btn-block btn-lg btn-success submit" type="submit"><i class='fa fa-sign-in'></i> Ingresar </button>
				</form>
				<?php if (isset($_smarty_tpl->tpl_vars['error']->value)) {?>
				<hr>
					<div class="alert alert-danger">
					  <strong>Error!</strong> <?php echo $_smarty_tpl->tpl_vars['error']->value;?>
.
					</div>
				<?php }?>
			<a href="Registro" class="btn btn-sm btn-primary register"><i class="fa fa fa-pencil"></i> Registrarse</a>
			<!--<a href="#" class="btn btn-sm btn-default forgot">Forgot your password?</a>-->
	</div>
</div>
	<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

</body>
<?php }
}
