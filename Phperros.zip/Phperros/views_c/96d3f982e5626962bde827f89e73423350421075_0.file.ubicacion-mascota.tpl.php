<?php
/* Smarty version 3.1.30, created on 2022-08-01 02:40:45
  from "C:\xampp\htdocs\Phperros\views\publicacion\ubicacion-mascota.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_62e7210d28aee1_01285599',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '96d3f982e5626962bde827f89e73423350421075' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Phperros\\views\\publicacion\\ubicacion-mascota.tpl',
      1 => 1573670791,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62e7210d28aee1_01285599 (Smarty_Internal_Template $_smarty_tpl) {
if ($_smarty_tpl->tpl_vars['existenCoordenadas']->value) {?>
	<div>
		<hr>
		<?php if ($_smarty_tpl->tpl_vars['publicacion']->value['tipo'] == 'E') {?>
			<h4>Encontrado en:</h4>
		<?php } else { ?>
			<h4>Perdido en las inmediaciones:</h4>
		<?php }?>
		<div id="map" style="height: 250px;margin-top: 5px;"></div>
	</div>
<?php }
}
}
