<?php
/* Smarty version 3.1.30, created on 2022-07-31 21:17:42
  from "C:\xampp\htdocs\Phperros\views\publicacion\publicacionespage.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_62e6d556530c92_67093655',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f763a66b59c870b487f63c27cd195d435aaa386c' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Phperros\\views\\publicacion\\publicacionespage.tpl',
      1 => 1573670791,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navBar.tpl' => 1,
    'file:publicacion/publicacionesconpaginado.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_62e6d556530c92_67093655 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<link rel="stylesheet" type="text/css" href="css/publicaciones.css">
<?php echo '<script'; ?>
 type="text/javascript" src="js/publicaciones.js"><?php echo '</script'; ?>
>
<body>
<?php $_smarty_tpl->_subTemplateRender("file:navBar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div id="container-principal" class="row">
	<div id="container-filtros" class="col-md-3 col-sm-3 col-xs-12">
		<div class="filtros">
			<h3 data-toggle="collapse" data-target="#filtros-especies">Especies</h3>
			<ul id="filtros-especies">
				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['especies']->value, 'esp');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['esp']->value) {
?>
					<li data-id="<?php echo $_smarty_tpl->tpl_vars['esp']->value['id'];?>
" data-tipo="especie"><?php echo $_smarty_tpl->tpl_vars['esp']->value['nombre'];?>
</li>
				<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

			</ul>
		</div>
		<div class="filtros">
			<h3 data-toggle="collapse" data-target="#filtros-razas">Razas</h3>
			<ul id="filtros-razas">
				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['razas']->value, 'raz');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['raz']->value) {
?>
					<li data-id="<?php echo $_smarty_tpl->tpl_vars['raz']->value['id'];?>
" data-especieid="<?php echo $_smarty_tpl->tpl_vars['raz']->value['especie_id'];?>
" data-tipo="raza"><?php echo $_smarty_tpl->tpl_vars['raz']->value['nombre'];?>
</li>
				<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

			</ul>
		</div>
		<div class="filtros">
			<h3 data-toggle="collapse" data-target="#filtros-barrios">Barrios</h3>
			<ul id="filtros-barrios">
				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['barrios']->value, 'bar');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['bar']->value) {
?>
					<li data-id="<?php echo $_smarty_tpl->tpl_vars['bar']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['bar']->value['nombre'];?>
</li>
				<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

			</ul>
		</div>
	</div>
	<div id="container-central" class="col-md-9 col-sm-9 col-xs-12">
		<div class="row">
			 <div class="radio">
  				<label><input type="radio" name="encontradosperdidos" value=0 checked>Todos</label>
			</div>
			<div class="radio">
  				<label><input type="radio" name="encontradosperdidos" value=1 >Encontrados</label>
			</div>
			<div class="radio">
  				<label><input type="radio" name="encontradosperdidos" value=2 >Perdidos</label>
			</div>
			<div class="col">
				<div class="pull-right" style="margin-right: 50px;">
					<div id="cantidad-x-paginas-dd" class="dropdown col-md-5  pull-left" >
	                    <a class="btn btn-default dropdown-toggle mediumFont" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
	                        <span id="cantidad-x-paginas-selected" data-val="10">10</span>
	                        <span class="caret"></span>
	                    </a>
	                    <ul id="cantidad-x-paginas" class="dropdown-menu">
	                    	<li data-id="1" title="10"><a>10</a></li>
	                    	<li data-id="2" title="20"><a>20</a></li>
	                    	<li data-id="3" title="50"><a>50</a></li>
	                    	<li data-id="Todas" title="Todas"><a>Todas</a></li>
	                    </ul>
                	</div>
				</div>
			</div>
		</div>
		<?php $_smarty_tpl->_subTemplateRender("file:publicacion/publicacionesconpaginado.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

	</div>
</div>
	<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

</body>
<?php }
}
