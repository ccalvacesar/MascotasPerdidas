<?php
/* Smarty version 3.1.30, created on 2022-07-31 21:17:42
  from "C:\xampp\htdocs\Phperros\views\publicacion\publicacionesconpaginado.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_62e6d5565c5df2_18051087',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1afef241a01e1563a574363ea968eece2c456476' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Phperros\\views\\publicacion\\publicacionesconpaginado.tpl',
      1 => 1573670791,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:publicacion/publicaciones.tpl' => 1,
    'file:paginacion.tpl' => 1,
  ),
),false)) {
function content_62e6d5565c5df2_18051087 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div id="container-publicaciones-paginado">
	<?php if ($_smarty_tpl->tpl_vars['canttotalpublicaciones']->value > 0) {?>
	<div id="container-publicaciones" class="row">
		<?php $_smarty_tpl->_subTemplateRender("file:publicacion/publicaciones.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

	</div>
	<div class="row">
		<?php $_smarty_tpl->_subTemplateRender("file:paginacion.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

	</div>
	<?php } else { ?>
		<h3>No existen publicaciones para los filtros aplicados</h3>
	<?php }?>
</div><?php }
}
