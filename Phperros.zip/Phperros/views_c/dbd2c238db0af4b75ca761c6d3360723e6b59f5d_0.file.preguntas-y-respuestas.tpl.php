<?php
/* Smarty version 3.1.30, created on 2022-08-01 02:40:45
  from "C:\xampp\htdocs\Phperros\views\publicacion\preguntas-y-respuestas.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_62e7210d2f6f40_47524696',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'dbd2c238db0af4b75ca761c6d3360723e6b59f5d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Phperros\\views\\publicacion\\preguntas-y-respuestas.tpl',
      1 => 1573670791,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62e7210d2f6f40_47524696 (Smarty_Internal_Template $_smarty_tpl) {
?>
<section id='seccion-preguntas'>
	<h3><i class='fa fa-comments'></i> Preguntas y respuestas</h3>
	<ul class='preguntas'>
		<?php if (count($_smarty_tpl->tpl_vars['preguntas']->value) > 0) {?>
				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['preguntas']->value, 'preg');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['preg']->value) {
?>
					<li class='pregunta-respuesta'>
						<article class='pregunta'><i class='fa fa-comment'></i> <?php echo $_smarty_tpl->tpl_vars['preg']->value['nombre_usuario'];?>
: <?php echo $_smarty_tpl->tpl_vars['preg']->value['texto'];?>
</article>
						<?php if (!is_null($_smarty_tpl->tpl_vars['preg']->value['respuesta'])) {?>
							<article class='respuesta'><i class='fa fa-comment icono-invertido'></i> <?php echo $_smarty_tpl->tpl_vars['preg']->value['respuesta'];?>
</article>
						<?php } elseif ($_smarty_tpl->tpl_vars['hayUsuarioLogueado']->value && $_smarty_tpl->tpl_vars['usuarioLogueado']->value['id'] == $_smarty_tpl->tpl_vars['publicacion']->value['usuario_id']) {?>
							<div class='row row-responder'>
								<div class='col-xs-12 col-sm-6 col-lg-8'>
									 <textarea class='form-control' rows='1'></textarea>
								</div>
								<div class='col-xs-6 col-lg-4'>
									<button class='btn btn-success btn-sm btn-responder' data-id-pregunta='<?php echo $_smarty_tpl->tpl_vars['preg']->value['id'];?>
'>Responder</button>
								</div>
							</div>
						<?php }?>
					</li>
				<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

		<?php } else { ?>
			<div class="alert alert-danger alert-chico" role="alert"> <i class="fa fa-exclamation-triangle"></i> No hay preguntas en esta publicación aún</div>
		<?php }?>
	</ul>
</section>
<section id='seccion-nueva-pregunta'>
	<?php if ($_smarty_tpl->tpl_vars['hayUsuarioLogueado']->value) {?>
		<?php if ($_smarty_tpl->tpl_vars['usuarioLogueado']->value['id'] !== $_smarty_tpl->tpl_vars['publicacion']->value['usuario_id']) {?>
			<h4>Haz una pregunta!</h4>		
			<div class='row row-preguntar'>
				<div class='col-xs-12 col-sm-6 col-lg-8'>
					 <textarea class='form-control' rows='2' id='txt-pregunta'></textarea>
				</div>
				<div class='col-xs-6 col-lg-4'>
					<button id='btn-preguntar' data-id-publicacion='<?php echo $_smarty_tpl->tpl_vars['publicacion']->value['id'];?>
' class='btn btn-success'><i class="fa fa-pencil"></i> Nueva pregunta</button>
				</div>
			</div>
		<?php }?>
	<?php } else { ?>
		<div class='row row-preguntar'>
			<div class='col-xs-12 col-sm-6 col-lg-8'>
				<a class='btn btn-danger' href='Login'><i class="fa fa-sign-in"></i> Inicia sesión para realizar una pregunta</a>
			</div>
		</div>
	<?php }?>
</section><?php }
}
