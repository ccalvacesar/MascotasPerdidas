<?php
/* Smarty version 3.1.30, created on 2022-08-01 00:41:19
  from "C:\xampp\htdocs\Phperros\views\publicacion\publicacionregistro.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_62e7050f0de6c0_76150321',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cf62e616fcef64fcdc3117bf62f03ad978e7e638' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Phperros\\views\\publicacion\\publicacionregistro.tpl',
      1 => 1573670791,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navBar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_62e7050f0de6c0_76150321 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<!--FILE UPLOAD-->
<link rel="stylesheet" href="vendor/fileupload/css/blueimp-gallery.min.css">
<!-- CSS to style the file input field as button and adjust the Bootstrap progress bars -->
<link rel="stylesheet" href="vendor/fileupload/css/jquery.fileupload.css">
<link rel="stylesheet" href="vendor/fileupload/css/jquery.fileupload-ui.css">
<!-- CSS adjustments for browsers with JavaScript disabled -->
<noscript><link rel="stylesheet" href="vendor/fileupload/css/jquery.fileupload-noscript.css"></noscript>
<noscript><link rel="stylesheet" href="vendor/fileupload/css/jquery.fileupload-ui-noscript.css"></noscript>
<!--FILE UPLOAD-->

<link rel="stylesheet" type="text/css" href="css/publicacionregistro.css">
 <!--GOOGLE MAP -->
<?php echo '<script'; ?>
 async defer
    src="https://maps.googleapis.com/maps/api/js?key=
			    AIzaSyC1w02yNO4juQRBJBaSE20p2-CZMZlaP5A&callback=initMap">
<?php echo '</script'; ?>
>
<!--GOOGLE MAP -->
<?php echo '<script'; ?>
 type="text/javascript" src="js/publicacionregistro.js"><?php echo '</script'; ?>
>

<body>
	<?php $_smarty_tpl->_subTemplateRender("file:navBar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

	<div id="modal-registro-publicacion" class="modal fade" data-backdrop="static">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4>Publicación finalizada con exito</h4>
                </div>
                <div id="modal-body-RegistroPublicacion" class="modal-body mediumFont">
	                <div class='row'>
	                    <a id="nueva-publicacion" class="btn btn-block btn-lg btn-success submit" type="button" href="Publicacion/registro/">Registrar nueva publicación</a>
	                </div>
	                <div class="row">
	                 	<a href='PanelUsuario' id="ver-publicaciones" class="btn btn-block btn-lg btn-primary submit" type="button">
	                 		Ver mis publicaciones
	                 	</a>
	                </div>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
	<div id="container-principal" class="row">
		<h3 style="margin:auto">Registro publicacion</h3>
		<div id="container-error" class="alert alert-danger oculto">
			<span id="close-error" class="fa fa-times"></span>
		    <strong>Error!</strong>
		    <p id="error"></p>
		</div>
		<div id="form-registro">
			 <div id="container-form-fields" class="row">
			  <div class="form-group col-12">
			    <label for="titulo" class="obligatorio">Titulo</label>
			    <input type="text" class="form-control" id="titulo">
			  </div>
			  <div class="form-group col-xs-12 col-sm-6 col-md-6 col-lg-6">
			    <label for="descripcion" class="obligatorio">Descripcion</label>
			    <textarea class="form-control" id="descripcion" rows="3"></textarea>
			  </div>
			  <div class="form-group col-xs-12 col-sm-6 col-md-6 col-lg-6">
			    <label for="select-tipo" class="obligatorio">Tipo</label>
			    <select class="form-control" id="select-tipo">
			    	<option value="-1">---</option>
			    	<option value="P">Perdido</option>
			    	<option value="E">Encontrado</option>
			    </select>
			  </div>
			  <div class="form-group col-6 ">
			    <label for="select-especie" class="obligatorio">Especie</label>
			    <select class="form-control" id="select-especie">
			    	<option value="-1">---</option>
			    	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['especies']->value, 'esp');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['esp']->value) {
?>
						<option value="<?php echo $_smarty_tpl->tpl_vars['esp']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['esp']->value['nombre'];?>
</option>
					<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

			    </select>
			  </div>
			  <div class="form-group col-6">
			    <label for="select-raza" class="obligatorio">Raza</label>
			    <select class="form-control" id="select-raza">
			    	<option value="-1" data-especieid="-1">---</option>
			     	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['razas']->value, 'raz');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['raz']->value) {
?>
						<option value="<?php echo $_smarty_tpl->tpl_vars['raz']->value['id'];?>
" data-especieid="<?php echo $_smarty_tpl->tpl_vars['raz']->value['especie_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['raz']->value['nombre'];?>
</option>
					<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

			    </select>
			  </div>
			  <div class="form-group col-12">
			    <label for="select-barrio" class="obligatorio">Barrio</label>
			    <select class="form-control" id="select-barrio">
			     	<option value="-1">---</option>
			      	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['barrios']->value, 'bar');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['bar']->value) {
?>
			      		<option value="<?php echo $_smarty_tpl->tpl_vars['bar']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['bar']->value['nombre'];?>
</option>
					<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

			    </select>
			  </div>
			  <div class="form-group col-12">
			  	<label for="select-barrio">Ubicación</label>
			    <div id="map"></div>
			  </div>
			  </div>
			  <hr>
			  <form id="fileupload" action="https://jquery-file-upload.appspot.com/" method="POST" enctype="multipart/form-data">
				  <div class="row fileupload-buttonbar">
	            	<div class="col-lg-7">
						<span class="btn btn-success fileinput-button">
				            <i class="fa fa-plus-circle"></i>
				            <span>Agregue imagenes...</span>
				            <input type="file" name="files[]" multiple>
			         	</span>
			         	<span style="font-style: italic;"> Intente arrastrar las imagenes aquí </span>
			         	<button  id="upload-all-images" type="submit" class="btn btn-primary start" style="display:none">
		                    <i class="glyphicon glyphicon-upload"></i>
		                    <span >Start upload</span>
		                </button>
		                <!--<button type="reset" class="btn btn-warning cancel">
		                    <i class="glyphicon glyphicon-ban-circle"></i>
		                    <span>Cancel upload</span>
		                </button>
		                <button type="button" class="btn btn-danger delete">
		                    <i class="glyphicon glyphicon-trash"></i>
		                    <span>Delete</span>
		                </button>
		                <input type="checkbox" class="toggle">
		                <span class="fileupload-process"></span>-->
		                </div>
					</div>
		         	<table id="tabla-imagenes" role="presentation" class="table table-striped">
		         		<tbody class="files">
		         			
		         		</tbody>
		         	</table>
		         	<button id="btn-registrar" class="btn btn-block btn-lg btn-success submit" type="button"><i class='fa fa-pencil'></i> Registrar</button>
	    	</form>
		</div>
	</div>
	<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

</body>

<!-- The template to display files available for upload -->
<?php echo '<script'; ?>
 id="template-upload" type="text/x-tmpl">
	{% for (var i=0, file; file=o.files[i]; i++) { %}
	    <tr class="template-upload">
	        <td>
	            <span class="preview"></span>
	        </td>
	        <td>
	            <p class="name">{%=file.name%}</p>
	            <strong class="error text-danger"></strong>
	        </td>
	        <td>
	            <p class="size">Processing...</p>
	            {% if (!i) { %}
	                <button class="btn btn-warning cancel">
	                    <i class="glyphicon glyphicon-ban-circle"></i>
	                    <span>Cancel</span>
	                </button>
	            {% } %}
	        </td>
	        <td>
	            {% if (!i && !o.options.autoUpload) { %}
	                <button class="btn btn-primary start" disabled>
	                    <i class="glyphicon glyphicon-upload"></i>
	                    <span>Start</span>
	                </button>
	            {% } %}
	            
	        </td>
	    </tr>
	{% } %}
<?php echo '</script'; ?>
>
<!-- The template to display files available for download -->
<?php echo '<script'; ?>
 id="template-download" type="text/x-tmpl">
{% for (var i=0, file; file=o.files[i]; i++) { %}
    <tr class="template-download">
        <td>
            <span class="preview">
                {% if (file.thumbnailUrl) { %}
                    <a href="{%=file.url%}" title="{%=file.name%}" download="{%=file.name%}" data-gallery><img src="{%=file.thumbnailUrl%}"></a>
                {% } %}
            </span>
        </td>
        <td>
            <p class="name">
                {% if (file.url) { %}
                    <a href="{%=file.url%}" title="{%=file.name%}" download="{%=file.name%}" {%=file.thumbnailUrl?'data-gallery':''%}>{%=file.name%}</a>
                {% } else { %}
                    <span>{%=file.name%}</span>
                {% } %}
            </p>
            {% if (file.error) { %}
                <div><span class="label label-danger">Error</span> {%=file.error%}</div>
            {% } %}
        </td>
        <td>
            <span class="size">{%=o.formatFileSize(file.size)%}</span>
        </td>
        <td>
            {% if (file.deleteUrl) { %}
                <button class="btn btn-danger delete" data-type="{%=file.deleteType%}" data-url="{%=file.deleteUrl%}"{% if (file.deleteWithCredentials) { %} data-xhr-fields='{"withCredentials":true}'{% } %}>
                    <i class="glyphicon glyphicon-trash"></i>
                    <span>Delete</span>
                </button>
                <input type="checkbox" name="delete" value="1" class="toggle">
            {% } else { %}
                <button class="btn btn-warning cancel">
                    <i class="glyphicon glyphicon-ban-circle"></i>
                    <span>Cancel</span>
                </button>
            {% } %}
        </td>
    </tr>
{% } %}
<?php echo '</script'; ?>
>

<!--FILE UPLOAD-->
<!-- ya se incluyo <?php echo '<script'; ?>
 src="vendor/fileupload/js/jquery.min.js"><?php echo '</script'; ?>
>-->
<!-- The jQuery UI widget factory, can be omitted if jQuery UI is already included -->
<?php echo '<script'; ?>
 src="vendor/fileupload/js/jquery.ui.widget.js"><?php echo '</script'; ?>
>
<!-- The Templates plugin is included to render the upload/download listings -->
<?php echo '<script'; ?>
 src="vendor/fileupload/js/tmpl.min.js"><?php echo '</script'; ?>
>
<!-- The Load Image plugin is included for the preview images and image resizing functionality -->
<?php echo '<script'; ?>
 src="vendor/fileupload/js/load-image.all.min.js"><?php echo '</script'; ?>
>
<!-- The Canvas to Blob plugin is included for image resizing functionality -->
<?php echo '<script'; ?>
 src="vendor/fileupload/js/canvas-to-blob.min.js"><?php echo '</script'; ?>
>
<!-- blueimp Gallery script -->
<?php echo '<script'; ?>
 src="vendor/fileupload/js/jquery.blueimp-gallery.min.js"><?php echo '</script'; ?>
>
<!-- The Iframe Transport is required for browsers without support for XHR file uploads -->
<?php echo '<script'; ?>
 src="vendor/fileupload/js/jquery.iframe-transport.js"><?php echo '</script'; ?>
>
<!-- The basic File Upload plugin -->
<?php echo '<script'; ?>
 src="vendor/fileupload/js/jquery.fileupload.js"><?php echo '</script'; ?>
>
<!-- The File Upload processing plugin -->
<?php echo '<script'; ?>
 src="vendor/fileupload/js/jquery.fileupload-process.js"><?php echo '</script'; ?>
>
<!-- The File Upload image preview & resize plugin -->
<?php echo '<script'; ?>
 src="vendor/fileupload/js/jquery.fileupload-image.js"><?php echo '</script'; ?>
>
<!-- The File Upload validation plugin -->
<?php echo '<script'; ?>
 src="vendor/fileupload/js/jquery.fileupload-validate.js"><?php echo '</script'; ?>
>
<!-- The File Upload user interface plugin -->
<?php echo '<script'; ?>
 src="vendor/fileupload/js/jquery.fileupload-ui.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="vendor/fileupload/js/main.js"><?php echo '</script'; ?>
>
<!--FILE UPLOAD--><?php }
}
