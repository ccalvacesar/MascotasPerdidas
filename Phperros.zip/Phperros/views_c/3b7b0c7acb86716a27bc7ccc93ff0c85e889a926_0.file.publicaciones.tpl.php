<?php
/* Smarty version 3.1.30, created on 2022-08-01 03:17:29
  from "C:\xampp\htdocs\Phperros\views\publicacion\publicaciones.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_62e729a913c613_02515871',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3b7b0c7acb86716a27bc7ccc93ff0c85e889a926' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Phperros\\views\\publicacion\\publicaciones.tpl',
      1 => 1573670791,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:publicacion/publicacion.tpl' => 1,
  ),
),false)) {
function content_62e729a913c613_02515871 (Smarty_Internal_Template $_smarty_tpl) {
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['publicaciones']->value, 'pub');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['pub']->value) {
?>
	<?php $_smarty_tpl->_subTemplateRender("file:publicacion/publicacion.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>

<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
}
}
