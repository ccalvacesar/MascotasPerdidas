<?php
/* Smarty version 3.1.30, created on 2022-08-01 00:41:10
  from "C:\xampp\htdocs\Phperros\views\panelUsuario\index.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_62e70506b1e551_55568305',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '189a16a7caa8682dc524a5da76b5ccd6cd9437c7' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Phperros\\views\\panelUsuario\\index.tpl',
      1 => 1573670791,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navBar.tpl' => 1,
    'file:panelUsuario/publicaciones-usuario.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_62e70506b1e551_55568305 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="en">
  
  <?php $_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


  <body>

    <?php $_smarty_tpl->_subTemplateRender("file:navBar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <!-- Page Content -->
    <div id="contenedor-panel" class="container">
    	<div class="row" style="float: right;">
    		<a href="PanelUsuario/verEstadisticas" class="btn btn-primary"><i class='fa fa-bar-chart'></i> Ver estadísticas de <?php echo $_smarty_tpl->tpl_vars['nombreSitio']->value;?>
</a>
    	</div>
    	<h3 class="my-4">
    		Bienvenido/a a tu panel de usuario, <?php echo $_smarty_tpl->tpl_vars['usuarioLogueado']->value['nombre'];?>
.
    	</h3>
    	<div class="row">
    		<?php if ($_smarty_tpl->tpl_vars['tienePublicaciones']->value) {?>
    			<?php $_smarty_tpl->_subTemplateRender("file:panelUsuario/publicaciones-usuario.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    		<?php } else { ?>
				<div class="alert alert-danger center" style="width:100%;"><i class='fa fa-exclamation-triangle'></i> Aún no tienes publicaciones en <?php echo $_smarty_tpl->tpl_vars['nombreSitio']->value;?>
</div>
				<div><a href="Publicacion/registro" class="btn btn-success"><i class='fa fa-pencil'></i> Haz tu primer publicación!</a></div>
    		<?php }?>
    	</div>
    	<hr>
    	<div class="row">
            <?php if ($_smarty_tpl->tpl_vars['tienePublicaciones']->value) {?>
    		  <a href="Publicacion/registro" class="btn btn-success"><i class='fa fa-pencil'></i> Registra una nueva publicación!</a>
            <?php }?>
    	</div>
    </div>
    <?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


  </body>

</html>
<?php }
}
