<?php
/* Smarty version 3.1.30, created on 2022-08-01 02:40:45
  from "C:\xampp\htdocs\Phperros\views\publicacion\publicacion-detalle.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_62e7210d1ce361_97797776',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a4d34f9a80eaa64e3ffd78c1bf1894621e3b97bf' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Phperros\\views\\publicacion\\publicacion-detalle.tpl',
      1 => 1659310364,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navBar.tpl' => 1,
    'file:publicacion/ubicacion-mascota.tpl' => 1,
    'file:publicacion/cerrar-publicacion.tpl' => 1,
    'file:publicacion/preguntas-y-respuestas.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_62e7210d1ce361_97797776 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<body>
<?php echo '<script'; ?>
 type='text/javascript' src='js/owl.carousel.min.js'><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type='text/javascript' src='js/publicacion-detalle.js'><?php echo '</script'; ?>
>
<?php if ($_smarty_tpl->tpl_vars['existenCoordenadas']->value) {?>
	<?php echo '<script'; ?>
 src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC1w02yNO4juQRBJBaSE20p2-CZMZlaP5A&callback=initMap" async defer><?php echo '</script'; ?>
>
<?php }?>
<link rel='stylesheet' type='text/css' href='css/publicacion-detalle.css'>
<?php $_smarty_tpl->_subTemplateRender("file:navBar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php if ($_smarty_tpl->tpl_vars['publicacion']->value['abierta'] == 0) {?>
	<div id="alert-publicacion-cerrada" class="alert alert-warning center">
	  <i class="fa fa-exclamation-triangle"></i> <strong>Atención!</strong> Esta publicación ya ha sido cerrada.
	</div>
<?php }?>
<div id='contenedor-publicacion' class='container'>
	<h1><?php echo $_smarty_tpl->tpl_vars['publicacion']->value['titulo'];?>
</h1>
	<div><?php echo $_smarty_tpl->tpl_vars['publicacion']->value['especie'];?>
 ><?php echo $_smarty_tpl->tpl_vars['publicacion']->value['raza'];?>
</div>	
	<section id='contenedor-galeria-descripcion'>
	<div class='row'>
		<div class='col-xs-12 col-sm-6 col-lg-8' id='galeria'>
			<div class='owl-carousel owl-theme'>
				<?php if (count($_smarty_tpl->tpl_vars['imagenes']->value) > 0) {?>
					<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['imagenes']->value, 'img');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['img']->value) {
?>
						<div><img class='img-responsive' src='<?php echo $_smarty_tpl->tpl_vars['img']->value;?>
'></div>
					<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

				<?php } else { ?>
					<div><img src="img/defecto.png"></div>
				<?php }?>
			</div>
		</div>Fr
		<div id='descripcion' class='col-xs-6 col-lg-4'>
			<?php if ($_smarty_tpl->tpl_vars['publicacion']->value['tipo'] == 'E') {?>
				<div class='alert alert-success alert-chico' role='alert'><i class='fa fa-check-circle'></i> Encontrado</div>
			<?php } else { ?>
				<div class='alert alert-danger alert-chico' role='alert'><i class='fa fa-search'></i> Perdido</div>
			<?php }?>
			<h4>Descripción</h4>
			<?php echo $_smarty_tpl->tpl_vars['publicacion']->value['descripcion'];?>

			<hr>
			<div>
				<h4>Contacto</h4>
				<div><i class='fa fa-user'></i> <?php echo $_smarty_tpl->tpl_vars['publicacion']->value['usr_nom'];?>
</div>
				<div><i class='fa fa-envelope'></i> <a href='mailto:<?php echo $_smarty_tpl->tpl_vars['publicacion']->value['usr_email'];?>
' target='_top'><?php echo $_smarty_tpl->tpl_vars['publicacion']->value['usr_email'];?>
</a></div>
			</div>
			<?php $_smarty_tpl->_subTemplateRender("file:publicacion/ubicacion-mascota.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

			<?php $_smarty_tpl->_subTemplateRender("file:publicacion/cerrar-publicacion.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
	
			<hr>
			<div>
				<a href="Publicacion/generarPublicacionPDF/<?php echo $_smarty_tpl->tpl_vars['publicacion']->value['id'];?>
" target="_blank" class="btn btn-success"><i class='fa fa-file-pdf-o'></i> Generar PDF</a>
			</div>
		</div>
	</div>
	</section>
	<hr>
	<?php $_smarty_tpl->_subTemplateRender("file:publicacion/preguntas-y-respuestas.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
	
</div>
	<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

	<span id='lat'><?php echo $_smarty_tpl->tpl_vars['publicacion']->value['latitud'];?>
</span>
	<span id='lon'><?php echo $_smarty_tpl->tpl_vars['publicacion']->value['longitud'];?>
</span>
</body><?php }
}
