<?php
/* Smarty version 3.1.30, created on 2022-07-31 20:51:27
  from "C:\xampp\htdocs\Phperros-master\views\footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_62e6cf2f39e1c2_39688097',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c05fe76b20261303b6fcdca3fef3b607298b4153' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Phperros-master\\views\\footer.tpl',
      1 => 1573670791,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62e6cf2f39e1c2_39688097 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!-- Footer -->
<footer class="py-5 bg-dark">
  <div class="container">
    <p class="m-0 text-center text-white">Copyright &copy; <?php echo $_smarty_tpl->tpl_vars['nombreSitio']->value;?>
 - <?php echo $_smarty_tpl->tpl_vars['autorSitio']->value;?>
 - 2018</p>
  </div>
  <!-- /.container -->
</footer><?php }
}
