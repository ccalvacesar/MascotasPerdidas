<?php

require_once 'controllers/FrontController.php';

FrontController::main();

