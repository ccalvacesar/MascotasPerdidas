$(document).ready(function(){
	$('.statistic-counter').counterUp({
    	delay: 10,
    	time: 900
	});
});


